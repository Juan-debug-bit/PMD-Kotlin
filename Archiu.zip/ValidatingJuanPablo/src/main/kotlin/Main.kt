/**
 *Crea un proyecto en IntelliJ cuyo nombre sea ValidatingTuNombre. El programa debe pedir al
 * usuario los siguientes datos indicando al usuario si son datos correctos validándolos
 * con expresiones regulares.
 *    - nombre completo: solo letras, guiones (-) y apóstrofe (') entre 3 y 50 caracteres,
 *    - email: formato de dirección de correo electrónico.
 *    - dni: 7 u 8 números seguidos de una letra mayúscula.
 *    - edad: número de como máximo 3 cifras.
 *    - teléfono: número de 9 cifras que debe empezar por 9, 6 o 7.
 *@author Juan Jiménez
 *@version 1.0
 */
fun main(args: Array<String>) {
    println("Introduce los siguientes datos: ")

    print("Nombre completo: ")
    val name = readln().toString()

    print("Email: ")
    val mail = readln()
    val checkMail = Regex("^[a-z_.]+@[a-z]+[a-z]{2,3}$")
    println(mail.contains(checkMail))

    print("DNI: ")
    val dni = readln()
    val checkDNI = Regex("^\\d{7,8}\\w{1}\$")
    println(dni.contains(checkDNI))

    print("Edad: ")
    val age = readln().toInt()
    print("Número de teléfono: ")
    val phoneNumber = readln().toInt()


}