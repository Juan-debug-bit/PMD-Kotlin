/**
 * Crea un proyecto en IntelliJ cuyo nombre sea CircleTuNombre. El programa pedirá al usuario
 * el radio de un círculo y mostrará por pantalla su perímetro, su área y el volumen de una esfera de ese radio su volumen.
 * @author Juan Jiménez
 * @version 1.0.0
 */
fun main(args: Array<String>) {

    print("Introduce el radio de un circulo: ")
    val circle = readln().toDouble()
    
}