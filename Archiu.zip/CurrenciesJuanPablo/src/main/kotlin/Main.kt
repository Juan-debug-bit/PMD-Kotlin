/**
 * Crea un proyecto en IntelliJ cuyo nombre sea CurrenciesTuNombre. El programa debe pedir una cantidad en € al usuario y a
 * continuación mostrará el equivalente en las siguientes divisas: $ (dólares), £ (libras) y ¥ (yenes) sabiendo que el cambio actual es:
 * - 1 € equivale a 1,07 $
 * - 1 € equivale a 0,86 £
 * - 1 € equivale a 157,49 ¥
 *
 * @author Juan Jiménez
 * @version 1.0.0
 */
fun main(args: Array<String>) {

    print("Introduce una cantidad en €:  ")
    val eur = readln().toInt()

    val dollar = (eur * 1.07)
    val pound = (eur * 0.86)
    val yen = (eur * 157.49)

    println("${eur}€ equivale a: ${dollar}$, ${pound}£, ${yen}¥")

}